# A gift for you

A Pen created on CodePen.io. Original URL: [https://codepen.io/rahul-sahni/pen/ByBWxGG](https://codepen.io/rahul-sahni/pen/ByBWxGG).

A 3d rotating gift that reveals a special gift on click